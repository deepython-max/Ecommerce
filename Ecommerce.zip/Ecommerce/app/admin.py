from django.contrib import admin

from .models import *

# Register your models here.

admin.site.register(Register)

# admin.site.register(Product)
admin.site.register(Product)

admin.site.register(ContactMessage)

admin.site.register(Category)

admin.site.register(Cart)

admin.site.register(CartItem)

admin.site.register(Cheakout)

admin.site.register(Wishlist)




